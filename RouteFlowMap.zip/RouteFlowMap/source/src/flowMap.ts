"use strict";

import { select, Selection } from "d3-selection";
import { geoNaturalEarth1, geoPath, GeoProjection } from "d3-geo";
import { zoom, zoomIdentity, ZoomBehavior, ZoomTransform } from "d3-zoom";
import { ticks } from "d3-array";
import { feature } from "topojson-client";
import worldTopology from "world-atlas/countries-50m.json";
import { Country } from "./countries";

export interface Route {
    key: string;
    origin: Country;
    destination: Country;
    /** Null when no measure is supplied; such routes are drawn at the minimum width. */
    value: number | null;
    rowIndexes: number[];
}

export interface FlowMapOptions {
    width: number;
    height: number;
    routeColor: string;
    minWidth: number;
    maxWidth: number;
    /** Value drawn at the maximum width. 0 means "the largest route currently shown". */
    scaleMax: number;
    /** 0..1 */
    routeOpacity: number;
    /** 0..1, how far the arc bows away from a straight line. */
    curvature: number;
    fadeFromOrigin: boolean;
    landColor: string;
    activeLandColor: string;
    borderColor: string;
    markerColor: string;
    zoomToRoutes: boolean;
    allowZoom: boolean;
    showLabels: boolean;
    labelSize: number;
    labelColor: string;
    showLegend: boolean;
    valueLabel: string;
    formatValue: (value: number) => string;
    /** Returns a short formatter (for example "$300M") suited to the given legend values. */
    makeCompactFormatter: (values: number[]) => (value: number) => string;
}

/** Maps a route's value to a line width. Shared by the routes and the legend so they always agree. */
export interface WidthScale {
    minWidth: number;
    maxWidth: number;
    /** Value drawn at maxWidth. */
    domainMax: number;
    widthFor(value: number | null): number;
}

/**
 * Width is proportional to value (half the value, half the width), from zero up to
 * `domainMax` at the maximum width. The minimum width is only a floor that keeps small
 * routes visible; values above `domainMax` are capped at the maximum width.
 */
export function createWidthScale(minWidth: number, maxWidth: number, domainMax: number): WidthScale {
    const lo = Math.max(0.25, Math.min(minWidth, maxWidth));
    const hi = Math.max(lo, Math.max(minWidth, maxWidth));
    return {
        minWidth: lo,
        maxWidth: hi,
        domainMax,
        widthFor: (value) => {
            if (value === null || !(domainMax > 0)) return lo;
            return Math.min(hi, Math.max(lo, (hi * Math.abs(value)) / domainMax));
        },
    };
}

/** Up to three round values (for example 300M, 200M, 100M) spanning zero to `domainMax`, largest first. */
export function legendValues(domainMax: number): number[] {
    if (!(domainMax > 0)) return [];
    const marks = ticks(0, domainMax, 4).filter((t) => t > 0);
    if (marks.length === 0) return [domainMax];
    if (marks.length <= 3) return marks.reverse();
    return [marks[marks.length - 1], marks[Math.floor((marks.length - 1) / 2)], marks[0]];
}

export interface TooltipItem {
    displayName: string;
    value: string;
}

export interface FlowMapHandlers {
    onRouteClick(route: Route, event: MouseEvent): void;
    onBackgroundClick(): void;
    onContextMenu(route: Route | null, event: MouseEvent): void;
    showTooltip(items: TooltipItem[], event: MouseEvent, route: Route | null): void;
    hideTooltip(): void;
}

interface MapNode {
    country: Country;
    x: number;
    y: number;
    outbound: number;
    inbound: number;
    isOrigin: boolean;
    isDestination: boolean;
}

interface DrawnRoute {
    route: Route;
    width: number;
    from: MapNode;
    to: MapNode;
}

type Group = Selection<SVGGElement, unknown, null, undefined>;

const SVG_NS = "http://www.w3.org/2000/svg";
const MAX_AUTO_ZOOM = 8;
const MAX_USER_ZOOM = 14;

interface CountryFeature {
    type: "Feature";
    id?: string | number;
    geometry: GeoJSON.Geometry;
    properties: { name?: string };
}

const countryFeatures: CountryFeature[] = (
    feature(worldTopology, worldTopology.objects.countries) as unknown as { features: CountryFeature[] }
).features
    // Antarctica (ISO 010) only adds empty space under a trade map.
    .filter((f) => String(f.id) !== "010");

let instanceCounter = 0;

/**
 * Chooses the longitude to centre the map on. A flat world map has to be split somewhere;
 * this puts the split where the least value has to cross it, assuming each route takes the
 * shorter way round the globe. For a New Zealand exporter that usually means splitting the
 * Atlantic, so trans-Pacific routes are drawn across the Pacific instead of the long way.
 */
export function chooseCentreLongitude(legs: { from: number; to: number; weight: number }[]): number {
    const unique = Array.from(new Set(legs.flatMap((l) => [Math.round(l.from), Math.round(l.to)]))).sort((a, b) => a - b);
    if (unique.length === 0) return 0;
    if (unique.length === 1) return unique[0];
    const mod = (v: number) => ((v % 360) + 360) % 360;
    const crossingCost = (cutAt: number) => legs.reduce((sum, leg) => {
        const delta = mod(leg.to - leg.from + 180) - 180; // signed shorter way round, -180..180
        const crosses = delta >= 0 ? mod(cutAt - leg.from) < delta : mod(leg.from - cutAt) < -delta;
        return crosses ? sum + leg.weight : sum;
    }, 0);
    let best = { cost: Infinity, gap: -1 };
    let cut = 180;
    for (let i = 0; i < unique.length; i++) {
        const a = unique[i];
        const b = i === unique.length - 1 ? unique[0] + 360 : unique[i + 1];
        const candidate = a + (b - a) / 2;
        const cost = crossingCost(candidate);
        if (cost < best.cost || (cost === best.cost && b - a > best.gap)) {
            best = { cost, gap: b - a };
            cut = candidate;
        }
    }
    let centre = cut + 180;
    while (centre > 180) centre -= 360;
    while (centre < -180) centre += 360;
    return Math.round(centre);
}

export class FlowMap {
    private readonly uid: string;
    private readonly svg: Selection<SVGSVGElement, unknown, null, undefined>;
    private readonly defs: Selection<SVGDefsElement, unknown, null, undefined>;
    private readonly mapLayer: Group;
    private readonly routeLayer: Group;
    private readonly markerLayer: Group;
    private readonly labelLayer: Group;
    private readonly legendLayer: Group;
    private readonly messageLayer: Group;
    private readonly zoomBehavior: ZoomBehavior<SVGSVGElement, unknown>;

    private projection: GeoProjection | null = null;
    private projectionKey = "";
    private viewKey = "";
    private transform: ZoomTransform = zoomIdentity;
    private nodes: MapNode[] = [];
    private routes: DrawnRoute[] = [];
    private options: FlowMapOptions | null = null;
    private handlers: FlowMapHandlers | null = null;
    private selectedKeys: Set<string> = new Set();

    constructor(container: HTMLElement) {
        // Each visual runs in its own frame, so a per-frame counter keeps gradient ids unique.
        this.uid = "rfm" + ++instanceCounter;
        const svgElement = document.createElementNS(SVG_NS, "svg") as SVGSVGElement;
        container.appendChild(svgElement);
        this.svg = select<SVGSVGElement, unknown>(svgElement).attr("class", "routeFlowMap");
        this.defs = this.svg.append("defs");
        this.mapLayer = this.svg.append("g").attr("class", "countries");
        this.routeLayer = this.svg.append("g").attr("class", "routes");
        this.markerLayer = this.svg.append("g").attr("class", "markers");
        this.labelLayer = this.svg.append("g").attr("class", "labels");
        this.legendLayer = this.svg.append("g").attr("class", "legend");
        this.messageLayer = this.svg.append("g").attr("class", "messages");

        this.zoomBehavior = zoom<SVGSVGElement, unknown>()
            .scaleExtent([1, MAX_USER_ZOOM])
            .on("zoom", (event) => {
                this.transform = event.transform;
                this.applyTransform();
            });

        this.svg.on("click", (event: MouseEvent) => {
            if (event.defaultPrevented) return;
            this.handlers?.onBackgroundClick();
        });
        this.svg.on("contextmenu", (event: MouseEvent) => {
            event.preventDefault();
            this.handlers?.onContextMenu(null, event);
        });
    }

    public setSelection(keys: Set<string>): void {
        this.selectedKeys = keys;
        this.drawRoutes();
    }

    public render(routes: Route[], unmatched: string[], options: FlowMapOptions, handlers: FlowMapHandlers): void {
        this.options = options;
        this.handlers = handlers;
        const width = Math.max(1, options.width);
        const height = Math.max(1, options.height);
        this.svg.attr("width", width).attr("height", height).attr("viewBox", `0 0 ${width} ${height}`);

        // --- projection and country shapes (rebuilt only when size or centring changes)
        const involved = new Map<string, Country>();
        routes.forEach((r) => {
            involved.set(r.origin.name, r.origin);
            involved.set(r.destination.name, r.destination);
        });
        const centre = chooseCentreLongitude(
            routes.map((r) => ({ from: r.origin.lon, to: r.destination.lon, weight: Math.abs(r.value ?? 1) || 1 })),
        );
        const projectionKey = `${width}x${height}@${centre}`;
        if (projectionKey !== this.projectionKey || !this.projection) {
            const pad = 6;
            this.projection = geoNaturalEarth1()
                .rotate([-centre, 0])
                .fitExtent([[pad, pad], [width - pad, height - pad]], { type: "Sphere" });
            const path = geoPath(this.projection);
            this.mapLayer
                .selectAll<SVGPathElement, unknown>("path")
                .data(countryFeatures)
                .join("path")
                .attr("d", (d) => path(d) || "")
                .attr("vector-effect", "non-scaling-stroke");
            this.projectionKey = projectionKey;
        }

        const activeIds = new Set(Array.from(involved.values()).map((c) => c.id).filter((id) => id));
        this.mapLayer
            .selectAll<SVGPathElement, CountryFeature>("path")
            .attr("fill", (d) => (d.id && activeIds.has(String(d.id)) ? options.activeLandColor : options.landColor))
            .attr("stroke", options.borderColor)
            .attr("stroke-width", 0.5);

        // --- nodes and routes in base (untransformed) map coordinates
        const nodeByName = new Map<string, MapNode>();
        const nodeFor = (country: Country): MapNode => {
            let node = nodeByName.get(country.name);
            if (!node) {
                const point = this.projection!([country.lon, country.lat]) || [0, 0];
                node = { country, x: point[0], y: point[1], outbound: 0, inbound: 0, isOrigin: false, isDestination: false };
                nodeByName.set(country.name, node);
            }
            return node;
        };
        const maxAbs = routes.reduce((m, r) => Math.max(m, Math.abs(r.value ?? 0)), 0);
        const scale = createWidthScale(options.minWidth, options.maxWidth, options.scaleMax > 0 ? options.scaleMax : maxAbs);
        this.routes = routes.map((route) => {
            const from = nodeFor(route.origin);
            const to = nodeFor(route.destination);
            from.isOrigin = true;
            to.isDestination = true;
            from.outbound += route.value ?? 0;
            to.inbound += route.value ?? 0;
            return { route, from, to, width: scale.widthFor(route.value) };
        });
        // Widest first, so thin routes stay visible on top.
        this.routes.sort((a, b) => b.width - a.width);
        this.nodes = Array.from(nodeByName.values());

        // --- zoom: keep the user's view while the data and size are unchanged
        const viewKey = [projectionKey, options.zoomToRoutes, routes.map((r) => r.key).sort().join("|")].join("#");
        const translateExtent: [[number, number], [number, number]] = [[0, 0], [width, height]];
        this.zoomBehavior.extent(translateExtent).translateExtent(translateExtent);
        if (viewKey !== this.viewKey) {
            this.transform = this.autoTransform(width, height);
            this.viewKey = viewKey;
        }
        if (options.allowZoom) {
            this.svg.call(this.zoomBehavior).on("dblclick.zoom", null);
            this.svg.call(this.zoomBehavior.transform, this.transform);
        } else {
            this.svg.on(".zoom", null);
            this.applyTransform();
        }

        this.drawLegend(scale, maxAbs > 0);
        this.drawMessages(routes.length === 0, unmatched);
    }

    /** Frames the countries in the data, leaving room for labels. */
    private autoTransform(width: number, height: number): ZoomTransform {
        const options = this.options!;
        if (!options.zoomToRoutes || this.nodes.length === 0) return zoomIdentity;
        const xs = this.nodes.map((n) => n.x);
        const ys = this.nodes.map((n) => n.y);
        const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
        const margin = { left: 48, right: 96, top: 34, bottom: 44 };
        const availW = Math.max(40, width - margin.left - margin.right);
        const availH = Math.max(40, height - margin.top - margin.bottom);
        const limit = this.nodes.length === 1 ? 4 : MAX_AUTO_ZOOM;
        let k = Math.min(limit, availW / Math.max(1, x1 - x0), availH / Math.max(1, y1 - y0));
        k = Math.max(1, k);
        let tx = margin.left + availW / 2 - k * (x0 + x1) / 2;
        let ty = margin.top + availH / 2 - k * (y0 + y1) / 2;
        tx = Math.min(0, Math.max(width - k * width, tx));
        ty = Math.min(0, Math.max(height - k * height, ty));
        return zoomIdentity.translate(tx, ty).scale(k);
    }

    private applyTransform(): void {
        this.mapLayer.attr("transform", this.transform.toString());
        this.drawRoutes();
        this.drawMarkersAndLabels();
    }

    private screen(node: MapNode): [number, number] {
        return this.transform.apply([node.x, node.y]);
    }

    private markerRadius(node: MapNode, maxInbound: number): number {
        if (!node.isDestination) return 3.5;
        const share = maxInbound > 0 ? Math.sqrt(Math.abs(node.inbound) / maxInbound) : 0;
        return 3.5 + 4.5 * share;
    }

    private drawRoutes(): void {
        const options = this.options;
        const handlers = this.handlers;
        if (!options || !handlers) return;
        const hasSelection = this.selectedKeys.size > 0;
        const gradientId = (d: DrawnRoute, i: number) => `${this.uid}_g${i}`;

        const geometry = this.routes.map((d) => {
            const [x1, y1] = this.screen(d.from);
            const [x2, y2] = this.screen(d.to);
            if (d.from === d.to) {
                // Domestic route: a ring around the country marker.
                const r = 11 + d.width;
                return { x1, y1, x2, y2, loop: true, path: `M${x1 - r},${y1}a${r},${r} 0 1,0 ${2 * r},0a${r},${r} 0 1,0 ${-2 * r},0` };
            }
            const dx = x2 - x1, dy = y2 - y1;
            const cx = (x1 + x2) / 2 - dy * options.curvature;
            const cy = (y1 + y2) / 2 + dx * options.curvature;
            return { x1, y1, x2, y2, loop: false, path: `M${x1},${y1}Q${cx},${cy} ${x2},${y2}` };
        });

        const useGradient = (i: number) => options.fadeFromOrigin && !geometry[i].loop;

        const gradients = this.defs
            .selectAll<SVGLinearGradientElement, DrawnRoute>("linearGradient")
            .data(this.routes)
            .join((enter) => {
                const g = enter.append("linearGradient").attr("gradientUnits", "userSpaceOnUse");
                g.append("stop").attr("offset", "0%").attr("stop-opacity", 0.18);
                g.append("stop").attr("offset", "100%").attr("stop-opacity", 1);
                return g;
            })
            .attr("id", gradientId)
            .attr("x1", (d, i) => geometry[i].x1)
            .attr("y1", (d, i) => geometry[i].y1)
            .attr("x2", (d, i) => geometry[i].x2)
            .attr("y2", (d, i) => geometry[i].y2);
        gradients.selectAll("stop").attr("stop-color", options.routeColor);

        const tooltipFor = (d: DrawnRoute): TooltipItem[] => {
            const items: TooltipItem[] = [
                { displayName: "Origin", value: d.route.origin.name },
                { displayName: "Destination", value: d.route.destination.name },
            ];
            if (d.route.value !== null) items.push({ displayName: options.valueLabel, value: options.formatValue(d.route.value) });
            return items;
        };

        const groups = this.routeLayer
            .selectAll<SVGGElement, DrawnRoute>("g.route")
            .data(this.routes)
            .join((enter) => {
                const g = enter.append("g").attr("class", "route");
                g.append("path").attr("class", "line").attr("fill", "none").attr("stroke-linecap", "round");
                g.append("path").attr("class", "hit").attr("fill", "none").attr("stroke", "transparent").attr("pointer-events", "stroke");
                return g;
            })
            .attr("opacity", (d) => options.routeOpacity * (hasSelection && !this.selectedKeys.has(d.route.key) ? 0.2 : 1));

        groups
            .select<SVGPathElement>("path.line")
            .attr("d", (d, i) => geometry[i].path)
            .attr("stroke", (d, i) => (useGradient(i) ? `url(#${gradientId(d, i)})` : options.routeColor))
            .attr("stroke-width", (d) => d.width);

        groups
            .select<SVGPathElement>("path.hit")
            .attr("d", (d, i) => geometry[i].path)
            .attr("stroke-width", (d) => Math.max(d.width + 6, 12))
            .style("cursor", "pointer")
            .on("click", (event: MouseEvent, d) => {
                event.stopPropagation();
                handlers.onRouteClick(d.route, event);
            })
            .on("contextmenu", (event: MouseEvent, d) => {
                event.preventDefault();
                event.stopPropagation();
                handlers.onContextMenu(d.route, event);
            })
            .on("mousemove", (event: MouseEvent, d) => handlers.showTooltip(tooltipFor(d), event, d.route))
            .on("mouseleave", () => handlers.hideTooltip());
    }

    private drawMarkersAndLabels(): void {
        const options = this.options;
        const handlers = this.handlers;
        if (!options || !handlers) return;
        const width = options.width, height = options.height;
        const maxInbound = this.nodes.reduce((m, n) => Math.max(m, Math.abs(n.inbound)), 0);
        const hasValues = this.routes.some((r) => r.route.value !== null);

        const placed = this.nodes
            .map((node) => {
                const [x, y] = this.screen(node);
                return { node, x, y, r: this.markerRadius(node, maxInbound) };
            })
            .sort((a, b) => Math.abs(b.node.inbound) + Math.abs(b.node.outbound) - (Math.abs(a.node.inbound) + Math.abs(a.node.outbound)));

        const tooltipFor = (node: MapNode): TooltipItem[] => {
            const items: TooltipItem[] = [{ displayName: "Country", value: node.country.name }];
            if (hasValues && node.isOrigin) items.push({ displayName: `${options.valueLabel} out`, value: options.formatValue(node.outbound) });
            if (hasValues && node.isDestination) items.push({ displayName: `${options.valueLabel} in`, value: options.formatValue(node.inbound) });
            return items;
        };

        this.markerLayer
            .selectAll<SVGCircleElement, (typeof placed)[number]>("circle")
            .data(placed)
            .join("circle")
            .attr("cx", (d) => d.x)
            .attr("cy", (d) => d.y)
            .attr("r", (d) => d.r)
            .attr("fill", (d) => (d.node.isDestination ? options.routeColor : "#FFFFFF"))
            .attr("stroke", (d) => (d.node.isOrigin ? options.markerColor : "#FFFFFF"))
            .attr("stroke-width", (d) => (d.node.isOrigin ? 2 : 1))
            .on("mousemove", (event: MouseEvent, d) => handlers.showTooltip(tooltipFor(d.node), event, null))
            .on("mouseleave", () => handlers.hideTooltip());

        // Labels: biggest countries first; skip any that would collide or fall off the edge.
        const fontSize = options.labelSize;
        const boxes: { x0: number; y0: number; x1: number; y1: number }[] = [];
        const labels = !options.showLabels ? [] : placed
            .map((d) => {
                const textWidth = d.node.country.name.length * fontSize * 0.56;
                let anchor: "start" | "end" = "start";
                let x = d.x + d.r + 4;
                if (x + textWidth > width - 2) {
                    anchor = "end";
                    x = d.x - d.r - 4;
                }
                const y = d.y + fontSize * 0.35;
                const box = {
                    x0: anchor === "start" ? x : x - textWidth,
                    x1: anchor === "start" ? x + textWidth : x,
                    y0: y - fontSize,
                    y1: y + fontSize * 0.3,
                };
                return { d, x, y, anchor, box };
            })
            .filter((label) => {
                const b = label.box;
                if (b.x0 < 0 || b.x1 > width || b.y0 < 0 || b.y1 > height) return false;
                if (boxes.some((o) => b.x0 < o.x1 + 2 && b.x1 > o.x0 - 2 && b.y0 < o.y1 + 1 && b.y1 > o.y0 - 1)) return false;
                boxes.push(b);
                return true;
            });

        this.labelLayer
            .selectAll<SVGTextElement, (typeof labels)[number]>("text")
            .data(labels)
            .join("text")
            .attr("x", (l) => l.x)
            .attr("y", (l) => l.y)
            .attr("text-anchor", (l) => l.anchor)
            .attr("font-size", fontSize)
            .attr("fill", options.labelColor)
            .text((l) => l.d.node.country.name);
    }

    /**
     * Width legend: round values with a bar drawn at exactly the width a route of that value
     * gets on the map. Bars have square ends so their thickness is easy to compare.
     */
    private drawLegend(scale: WidthScale, hasValues: boolean): void {
        const options = this.options!;
        this.legendLayer.selectAll("*").remove();
        if (!options.showLegend || !hasValues) return;
        const values = legendValues(scale.domainMax);
        if (values.length === 0) return;
        const format = options.makeCompactFormatter(values);
        const samples = values.map((value) => ({ value, width: scale.widthFor(value) }));
        const barLength = 36;
        const gap = 5;
        const x = 12;
        const totalHeight = samples.reduce((sum, s) => sum + Math.max(13, s.width) + gap, 0);
        let y = options.height - 10 - totalHeight;
        this.legendLayer
            .append("text")
            .attr("x", x)
            .attr("y", y - 5)
            .attr("font-size", 10)
            .attr("font-weight", 600)
            .attr("fill", options.labelColor)
            .text(options.valueLabel);
        samples.forEach((sample) => {
            const rowHeight = Math.max(13, sample.width);
            const cy = y + rowHeight / 2;
            this.legendLayer
                .append("rect")
                .attr("class", "sample")
                .attr("x", x)
                .attr("y", cy - sample.width / 2)
                .attr("width", barLength)
                .attr("height", sample.width)
                .attr("fill", options.routeColor)
                .attr("fill-opacity", options.routeOpacity);
            this.legendLayer
                .append("text")
                .attr("x", x + barLength + 8)
                .attr("y", cy + 3.5)
                .attr("font-size", 10)
                .attr("fill", options.labelColor)
                .text(format(sample.value));
            y += rowHeight + gap;
        });
    }

    private drawMessages(empty: boolean, unmatched: string[]): void {
        const options = this.options!;
        this.messageLayer.selectAll("*").remove();
        if (unmatched.length > 0) {
            const shown = unmatched.slice(0, 4).join(", ");
            const more = unmatched.length > 4 ? ` and ${unmatched.length - 4} more` : "";
            this.messageLayer
                .append("text")
                .attr("class", "notice")
                .attr("x", 12)
                .attr("y", 16)
                .attr("font-size", 10)
                .attr("fill", "#8A8A86")
                .text(`Not recognised as a country: ${shown}${more}`);
        }
        if (empty && unmatched.length === 0) {
            this.messageLayer
                .append("text")
                .attr("class", "hint")
                .attr("x", options.width / 2)
                .attr("y", options.height / 2)
                .attr("text-anchor", "middle")
                .attr("font-size", 12)
                .attr("fill", "#6B6B68")
                .text("Add an origin country, a destination country and a value such as revenue");
        }
    }
}
