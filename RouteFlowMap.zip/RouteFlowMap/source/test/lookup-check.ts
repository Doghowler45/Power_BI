// Node check of country matching: prints each input and what it resolves to.
import { findCountry } from "../src/countries";
import { chooseCentreLongitude } from "../src/flowMap";

const expected: [string, string | undefined][] = [
    ["New Zealand", "New Zealand"], ["nz", "New Zealand"], ["NZL", "New Zealand"], ["Aotearoa", "New Zealand"],
    ["USA", "United States"], ["U.S.A.", "United States"], ["United States of America", "United States"],
    ["UK", "United Kingdom"], ["Great Britain", "United Kingdom"],
    ["Korea, Republic of", "South Korea"], ["Korea", "South Korea"], ["North Korea", "North Korea"],
    ["Viet Nam", "Vietnam"], ["Hong Kong SAR", "Hong Kong"], ["Chinese Taipei", "Taiwan"], ["PRC", "China"],
    ["Russian Federation", "Russia"], ["The Netherlands", "Netherlands"], ["Holland", "Netherlands"],
    ["Congo", "Republic of the Congo"], ["DRC", "DR Congo"], ["UAE", "United Arab Emirates"],
    ["Côte d'Ivoire", "Ivory Coast"], ["Fiji", "Fiji"], ["Samoa", "Samoa"], ["Tonga", "Tonga"],
    ["Papua New Guinea", "Papua New Guinea"], ["Singapore", "Singapore"], ["Georgia", "Georgia"],
    ["Guinea", "Guinea"], ["Niger", "Niger"], ["Nigeria", "Nigeria"], ["Dominica", "Dominica"],
    ["Dominican Republic", "Dominican Republic"], ["India", "India"], ["Atlantis", undefined], ["", undefined],
];

let failures = 0;
for (const [input, want] of expected) {
    const got = findCountry(input)?.name;
    if (got !== want) {
        failures++;
        console.log(`MISMATCH  "${input}" -> ${got} (expected ${want})`);
    }
}
console.log(`${expected.length - failures}/${expected.length} lookups as expected`);

// NZ -> USA (heavy) and NZ -> UK: the split should not fall in the Pacific.
const centre = chooseCentreLongitude([
    { from: 174, to: -97, weight: 240 },
    { from: 174, to: -2, weight: 95 },
    { from: 174, to: 105, weight: 310 },
]);
console.log(`centre longitude for NZ exporter sample: ${centre}`);
