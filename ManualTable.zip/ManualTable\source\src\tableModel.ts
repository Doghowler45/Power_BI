"use strict";

export type ColumnType = "text" | "number";

export interface TableColumn {
    name: string;
    type: ColumnType;
}

/** The whole table. Every cell is kept as the text that was typed, so nothing is lost by formatting. */
export interface TableData {
    columns: TableColumn[];
    rows: string[][];
    /** Fill colour of each cell, the same shape as `rows`. An empty string means no fill. */
    fills: string[][];
    /** Fill colour of each header cell, one per column. An empty string means no fill of its own. */
    headerFills: string[];
    /** Outline colour of each cell, the same shape as `rows`. An empty string means no outline. */
    outlines: string[][];
    /** Outline colour of each header cell, one per column. */
    headerOutlines: string[];
    /** Width of each column in pixels. 0 means automatic. */
    widths: number[];
    /** Height of each row in pixels, the same length as `rows`. 0 means automatic. */
    heights: number[];
    /** Height of the header row in pixels. 0 means automatic. */
    headerHeight: number;
}

export const MIN_WIDTH = 30;
export const MAX_WIDTH = 800;
export const MIN_HEIGHT = 16;
export const MAX_HEIGHT = 300;

/** A column width or row height as saved: 0 for automatic, otherwise a whole number inside the limits. */
export function cleanSize(value: unknown, min: number, max: number): number {
    const n = typeof value === "number" ? value : Number(value);
    if (!isFinite(n) || n <= 0) return 0;
    return Math.round(Math.min(max, Math.max(min, n)));
}

/** A table with no highlights: a blank fill for every cell. */
export function blankFills(rows: string[][]): string[][] {
    return rows.map((row) => row.map(() => ""));
}

export const MAX_ROWS = 300;
export const MAX_COLUMNS = 30;

/** Shown when the visual is first added and nothing has been typed yet. */
export function starterTable(): TableData {
    return {
        columns: [
            { name: "Item", type: "text" },
            { name: "Amount", type: "number" },
            { name: "Comment", type: "text" },
        ],
        rows: [["", "", ""], ["", "", ""], ["", "", ""]],
        fills: [["", "", ""], ["", "", ""], ["", "", ""]],
        headerFills: ["", "", ""],
        outlines: [["", "", ""], ["", "", ""], ["", "", ""]],
        headerOutlines: ["", "", ""],
        widths: [0, 0, 0],
        heights: [0, 0, 0],
        headerHeight: 0,
    };
}

export function cloneTable(data: TableData): TableData {
    return {
        columns: data.columns.map((c) => ({ ...c })),
        rows: data.rows.map((r) => r.slice()),
        fills: data.fills.map((r) => r.slice()),
        headerFills: data.headerFills.slice(),
        outlines: data.outlines.map((r) => r.slice()),
        headerOutlines: data.headerOutlines.slice(),
        widths: data.widths.slice(),
        heights: data.heights.slice(),
        headerHeight: data.headerHeight,
    };
}

/** Makes every row the same length as the header and every cell a string. */
function normalise(data: TableData): TableData {
    const columns = data.columns.slice(0, MAX_COLUMNS).map((c) => ({
        name: typeof c.name === "string" ? c.name : String(c.name ?? ""),
        type: c.type === "number" ? "number" as const : "text" as const,
    }));
    const rows = data.rows.slice(0, MAX_ROWS).map((row) =>
        columns.map((_, i) => {
            const cell = Array.isArray(row) ? row[i] : undefined;
            return cell === null || cell === undefined ? "" : String(cell);
        }));
    // Tables saved before highlighting existed have no fills; anything that is not a colour is dropped.
    const colour = (fill: unknown): string => (typeof fill === "string" && /^#[0-9a-fA-F]{3,8}$/.test(fill) ? fill : "");
    const savedFills = Array.isArray(data.fills) ? data.fills : [];
    const fills = rows.map((row, r) => columns.map((_, c) => colour(Array.isArray(savedFills[r]) ? savedFills[r][c] : "")));
    const savedHeaderFills = Array.isArray(data.headerFills) ? data.headerFills : [];
    const headerFills = columns.map((_, c) => colour(savedHeaderFills[c]));
    const savedOutlines = Array.isArray(data.outlines) ? data.outlines : [];
    const outlines = rows.map((row, r) => columns.map((_, c) => colour(Array.isArray(savedOutlines[r]) ? savedOutlines[r][c] : "")));
    const savedHeaderOutlines = Array.isArray(data.headerOutlines) ? data.headerOutlines : [];
    const headerOutlines = columns.map((_, c) => colour(savedHeaderOutlines[c]));
    // Sizes: tables saved before resizing existed have none, which means automatic everywhere.
    const savedWidths = Array.isArray(data.widths) ? data.widths : [];
    const savedHeights = Array.isArray(data.heights) ? data.heights : [];
    const widths = columns.map((_, c) => cleanSize(savedWidths[c], MIN_WIDTH, MAX_WIDTH));
    const heights = rows.map((_, r) => cleanSize(savedHeights[r], MIN_HEIGHT, MAX_HEIGHT));
    const headerHeight = cleanSize(data.headerHeight, MIN_HEIGHT, MAX_HEIGHT);
    return { columns, rows, fills, headerFills, outlines, headerOutlines, widths, heights, headerHeight };
}

/** Reads the table saved with the report. Returns null when nothing usable is stored. */
export function parseData(json: unknown): TableData | null {
    if (typeof json !== "string" || !json.trim()) return null;
    try {
        const parsed = JSON.parse(json);
        if (!parsed || !Array.isArray(parsed.columns) || !Array.isArray(parsed.rows) || parsed.columns.length === 0) return null;
        return normalise(parsed as TableData);
    } catch {
        return null;
    }
}

export function serialiseData(data: TableData): string {
    const clean = normalise(data);
    // Highlights are only written when there are some, to keep the saved text short.
    const saved: {
        v: number; columns: TableColumn[]; rows: string[][];
        fills?: string[][]; headerFills?: string[]; outlines?: string[][]; headerOutlines?: string[];
        widths?: number[]; heights?: number[]; headerHeight?: number;
    } = { v: 4, columns: clean.columns, rows: clean.rows };
    if (clean.fills.some((row) => row.some((fill) => fill))) saved.fills = clean.fills;
    if (clean.headerFills.some((fill) => fill)) saved.headerFills = clean.headerFills;
    if (clean.outlines.some((row) => row.some((outline) => outline))) saved.outlines = clean.outlines;
    if (clean.headerOutlines.some((outline) => outline)) saved.headerOutlines = clean.headerOutlines;
    if (clean.widths.some((w) => w > 0)) saved.widths = clean.widths;
    if (clean.heights.some((h) => h > 0)) saved.heights = clean.heights;
    if (clean.headerHeight > 0) saved.headerHeight = clean.headerHeight;
    return JSON.stringify(saved);
}

/**
 * Reads a typed number. Accepts thousands separators, a currency symbol, a percent sign and
 * accounting-style brackets for negatives, for example "1,250", "$1,250.50", "(300)" or "-12%".
 * Returns null for empty cells and for text that is not a number.
 */
export function parseNumber(text: string): number | null {
    let t = text.trim();
    if (!t) return null;
    let negative = false;
    if (/^\(.*\)$/.test(t)) {
        negative = true;
        t = t.slice(1, -1);
    }
    t = t.replace(/[\s,$€£¥%]/g, "").replace(/−/g, "-");
    if (t.startsWith("-")) {
        negative = !negative;
        t = t.slice(1);
    } else if (t.startsWith("+")) {
        t = t.slice(1);
    }
    if (!/^(\d+\.?\d*|\.\d+)$/.test(t)) return null;
    const value = Number(t);
    if (!isFinite(value)) return null;
    return negative ? -value : value;
}

export interface NumberStyle {
    locale: string;
    decimals: number;
    /** Show negatives as (1,200) instead of -1,200. */
    brackets: boolean;
    /** Put in front of every number, for example "$". */
    prefix: string;
}

export function formatNumber(value: number, style: NumberStyle): string {
    const decimals = Math.min(6, Math.max(0, Math.round(style.decimals) || 0));
    let body: string;
    try {
        body = new Intl.NumberFormat(style.locale || undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(Math.abs(value));
    } catch {
        body = Math.abs(value).toFixed(decimals);
    }
    // A value that rounds to zero is shown without a sign.
    const isNegative = value < 0 && Number(Math.abs(value).toFixed(decimals)) !== 0;
    const text = `${style.prefix}${body}`;
    if (!isNegative) return text;
    return style.brackets ? `(${text})` : `-${text}`;
}

/** What a cell shows when it is not being edited. */
export function displayCell(raw: string, column: TableColumn, style: NumberStyle): string {
    if (column.type !== "number") return raw;
    const value = parseNumber(raw);
    // Text typed into a number column is left as it is, so nothing silently disappears.
    return value === null ? raw : formatNumber(value, style);
}

/** Sum of each number column (null for text columns, and for number columns with no numbers in them). */
export function columnTotals(data: TableData): (number | null)[] {
    return data.columns.map((column, c) => {
        if (column.type !== "number") return null;
        let total = 0, found = false;
        data.rows.forEach((row) => {
            const value = parseNumber(row[c] || "");
            if (value !== null) {
                total += value;
                found = true;
            }
        });
        return found ? total : null;
    });
}

// Adding and removing rows and columns. Every per-row and per-column list (values, fills,
// outlines, sizes) is changed together here, so they can never fall out of step.

/** Adds an empty row at the bottom. */
export function addRow(data: TableData): void {
    data.rows.push(data.columns.map(() => ""));
    data.fills.push(data.columns.map(() => ""));
    data.outlines.push(data.columns.map(() => ""));
    data.heights.push(0);
}

export function removeRow(data: TableData, row: number): void {
    data.rows.splice(row, 1);
    data.fills.splice(row, 1);
    data.outlines.splice(row, 1);
    data.heights.splice(row, 1);
}

/** Adds an empty text column on the right. */
export function addColumn(data: TableData): void {
    data.columns.push({ name: `Column ${data.columns.length + 1}`, type: "text" });
    data.rows.forEach((row) => row.push(""));
    data.fills.forEach((row) => row.push(""));
    data.outlines.forEach((row) => row.push(""));
    data.headerFills.push("");
    data.headerOutlines.push("");
    data.widths.push(0);
}

export function removeColumn(data: TableData, column: number): void {
    data.columns.splice(column, 1);
    data.rows.forEach((row) => row.splice(column, 1));
    data.fills.forEach((row) => row.splice(column, 1));
    data.outlines.forEach((row) => row.splice(column, 1));
    data.headerFills.splice(column, 1);
    data.headerOutlines.splice(column, 1);
    data.widths.splice(column, 1);
}

/** Splits text copied from a spreadsheet (tabs between cells, new lines between rows) into a grid. */
export function parseClipboard(text: string): string[][] {
    const lines = text.replace(/\r\n?/g, "\n").split("\n");
    // Spreadsheets end the copied block with a new line; drop that empty last row.
    if (lines.length > 1 && lines[lines.length - 1] === "") lines.pop();
    return lines.map((line) => line.split("\t"));
}

/** True when clipboard text covers more than one cell. */
export function isGridPaste(text: string): boolean {
    return /\t/.test(text) || /[\r\n]/.test(text.replace(/[\r\n]+$/, ""));
}

/**
 * Writes a pasted grid into the table starting at the given cell, adding rows and columns
 * if the block runs past the edge. Returns a new table; the original is not changed.
 */
export function pasteGrid(data: TableData, startRow: number, startColumn: number, grid: string[][]): TableData {
    const next = cloneTable(data);
    const neededColumns = Math.min(MAX_COLUMNS, startColumn + Math.max(0, ...grid.map((r) => r.length)));
    while (next.columns.length < neededColumns) addColumn(next);
    const neededRows = Math.min(MAX_ROWS, startRow + grid.length);
    while (next.rows.length < neededRows) addRow(next);
    grid.forEach((line, r) => {
        line.forEach((cell, c) => {
            const row = startRow + r, column = startColumn + c;
            if (row < next.rows.length && column < next.columns.length) next.rows[row][column] = cell.trim();
        });
    });
    return next;
}
