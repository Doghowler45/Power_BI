# Route Flow Map

A Power BI custom visual that draws origin-to-destination routes between countries, with line width set by a measure such as revenue.

## Fields

| Field | What to put in it |
| --- | --- |
| Origin country | A country name (`New Zealand`), common alias (`USA`, `UK`, `Viet Nam`) or ISO code (`NZ`, `NZL`) |
| Destination country | Same as above |
| Revenue | Any measure; it sets the width of each route. Optional: without it, all routes are the same width |

Countries the visual cannot match are listed in a small notice at the top left of the visual. To add a spelling, edit `manualAliases` in `scripts/build-data.js`, then run `npm run build-data` and rebuild.

## Line widths and the legend

- Width is proportional to the value: a route with half the revenue is drawn half as wide.
- The largest route currently shown gets the **Maximum width**. Because of that, filtering rescales the lines and the legend values change with it.
- To stop the rescaling, set **Routes > Value at maximum width** to a fixed number (for example 400000000). Widths and the legend then stay the same under any filter; routes above that value are capped at the maximum width.
- **Minimum width** is only a floor so that small routes stay visible. Routes at the floor look the same width even if their values differ.
- The legend shows up to three round values between zero and the top of the scale, each drawn at exactly the width a route of that value gets.

## Rebuilding

Needs Node.js. Build from a local drive: npm does not work from a network path such as `\\server\share`.

```
npm install
npm run build-data
npx pbiviz package
```

The packaged visual is written to `dist/`. Before sharing it more widely, replace the placeholder author name, email and support URL in `pbiviz.json`.

## Checks

`test/` holds a browser harness (`harness.ts`, `index.html`), a country-matching check (`lookup-check.ts`) and a run of the packaged code against a mock Power BI host (`smoke.html`). Bundle the TypeScript ones with esbuild, for example:

```
npx esbuild test/lookup-check.ts --bundle --platform=node --outfile=test/lookup-check.js --loader:.json=json
node test/lookup-check.js
```

## Data sources

- Country shapes: Natural Earth 1:50m via the `world-atlas` package. No map tiles or web requests are used.
- Country names, codes and centre points: the `world-countries` package (Open Database License).
