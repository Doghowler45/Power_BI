// Browser test harness: renders the map with sample routes, outside Power BI.
import { findCountry } from "../src/countries";
import { FlowMap, FlowMapOptions, Route } from "../src/flowMap";

const samples: [string, string, number][] = [
    ["New Zealand", "China", 310e6],
    ["New Zealand", "USA", 240e6],
    ["NZ", "Japan", 150e6],
    ["New Zealand", "United Kingdom", 95e6],
    ["New Zealand", "Viet Nam", 70e6],
    ["New Zealand", "Australia", 120e6],
    ["New Zealand", "Thailand", 55e6],
    ["New Zealand", "Germany", 60e6],
    ["New Zealand", "UAE", 35e6],
    ["New Zealand", "Hong Kong SAR", 48e6],
    ["New Zealand", "Singapore", 30e6],
    ["New Zealand", "New Zealand", 260e6],
    ["Peru", "USA", 40e6],
    ["Chile", "CHN", 65e6],
    ["Australia", "New Zealand", 45e6],
    ["South Africa", "UK", 22e6],
    ["New Zealand", "Atlantis", 5e6],
    ["New Zealand", "Korea", 42e6],
    ["New Zealand", "Taiwan", 58e6],
    ["New Zealand", "India", 26e6],
];

const params = new URLSearchParams(location.search);
const subset = params.get("set") === "regional"
    ? samples.filter(([, d]) => ["Australia", "New Zealand", "Japan", "China", "Singapore", "Taiwan"].includes(d))
    : samples;

const unmatched: string[] = [];
const byKey = new Map<string, Route>();
subset.forEach(([o, d, v], i) => {
    const origin = findCountry(o);
    const destination = findCountry(d);
    if (!origin) unmatched.push(o);
    if (!destination) unmatched.push(d);
    if (!origin || !destination) return;
    const key = `${origin.name}>${destination.name}`;
    const route = byKey.get(key) || { key, origin, destination, value: 0, rowIndexes: [] };
    route.value = (route.value ?? 0) + v;
    route.rowIndexes.push(i);
    byKey.set(key, route);
});

const container = document.getElementById("visual")!;
const options: FlowMapOptions = {
    width: container.clientWidth,
    height: container.clientHeight,
    projection: params.get("mode") === "flat" ? "flat" : "globe",
    oceanColor: "#EEF3F1",
    showZoomButtons: true,
    hoverHighlight: true,
    hoverCard: true,
    routeColor: "#57B133",
    minWidth: 1.5,
    maxWidth: 14,
    scaleMax: 0,
    routeOpacity: 0.85,
    curvature: 0.2,
    fadeFromOrigin: true,
    landColor: "#E4E6DF",
    activeLandColor: "#CFE1B6",
    borderColor: "#FFFFFF",
    markerColor: "#1C1C1B",
    zoomToRoutes: params.get("zoom") !== "off",
    allowZoom: true,
    showLabels: true,
    labelSize: 10,
    labelColor: "#1C1C1B",
    showLegend: true,
    valueLabel: "Revenue",
    formatValue: (v) => "$" + Math.round(v).toLocaleString("en-NZ"),
    makeCompactFormatter: () => (v) => "$" + Math.round(v / 1e6) + "M",
};

const log = document.getElementById("log")!;
const map = new FlowMap(container);
const started = performance.now();
map.render(params.get("set") === "empty" ? [] : Array.from(byKey.values()), params.get("set") === "empty" ? [] : unmatched, options, {
    onRouteClick: (route) => {
        log.textContent = "clicked " + route.key;
        map.setSelection(new Set([route.key]));
    },
    onCountryClick: (routes) => { log.textContent = "country click: " + routes.length + " routes"; },
    onBackgroundClick: () => map.setSelection(new Set()),
    onContextMenu: () => undefined,
    showTooltip: (items) => { log.textContent = items.map((i) => `${i.displayName}: ${i.value}`).join(" | "); },
    hideTooltip: () => undefined,
});
if (params.get("select")) map.setSelection(new Set([params.get("select")!]));
const renderMs = Math.round(performance.now() - started);

// Optional steps for screenshots: zoom in N times with the on-screen "+" button, then hover a route.
const plus = container.querySelector(".controls .button") as SVGGElement | null;
const zoomSteps = Number(params.get("zoomin") || 0);
for (let i = 0; i < zoomSteps; i++) plus?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
window.setTimeout(() => {
    const hoverKey = params.get("hover");
    const hits = Array.from(container.querySelectorAll<SVGPathElement>("g.route path.hit"));
    const routesShown = hits.filter((h) => (h.getAttribute("d") || "").length > 0).length;
    let hitTest = "n/a";
    if (hoverKey) {
        const keys = Array.from(byKey.values()).sort((a, b) => Math.abs(b.value ?? 0) - Math.abs(a.value ?? 0)).map((r) => r.key);
        const target = hits[keys.indexOf(hoverKey)];
        if (target) {
            // Real hit-testing: is the route the top element at its own midpoint?
            const mid = target.getPointAtLength(target.getTotalLength() / 2);
            const box = container.getBoundingClientRect();
            const top = document.elementFromPoint(box.left + mid.x, box.top + mid.y);
            hitTest = top === target ? "route is hit at its midpoint" : `midpoint hits <${top ? top.tagName : "nothing"} class=${top ? top.getAttribute("class") : ""}>`;
            target.dispatchEvent(new MouseEvent("mouseenter", { bubbles: false }));
        } else hitTest = "route not found";
    }
    const card = Array.from(container.querySelectorAll(".card text")).map((t) => t.textContent).join(" | ");
    log.textContent = `first render ${renderMs} ms; routes with a visible path ${routesShown}/${hits.length}; markers ${container.querySelectorAll(".markers circle.dot").length}; buttons ${container.querySelectorAll(".controls .button").length}; hit test: ${hitTest}; card: ${card || "(none)"}`;
}, 600);

// Report lookups so the screenshot run can assert on them.
const checks = ["nz", "NZL", "U.S.A.", "Côte d'Ivoire", "Korea, Republic of", "Türkiye", "The Netherlands", "Czechia", "Congo", "DRC", "Atlantis"];
document.getElementById("checks")!.textContent = checks.map((c) => `${c} -> ${findCountry(c)?.name ?? "NOT FOUND"}`).join("; ");
