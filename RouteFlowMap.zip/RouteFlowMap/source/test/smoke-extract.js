// Pulls the bundled JS and CSS out of an unzipped .pbiviz so the packaged code can be
// run in a browser against a mock Power BI host. Usage: node smoke-extract.js <unzippedDir> <outDir>
const fs = require("fs");
const path = require("path");

const [unzipped, outDir] = process.argv.slice(2);
const resources = path.join(unzipped, "resources");
const file = fs.readdirSync(resources).find((f) => f.endsWith(".pbiviz.json"));
const pkg = JSON.parse(fs.readFileSync(path.join(resources, file), "utf8"));
fs.writeFileSync(path.join(outDir, "packaged.js"), pkg.content.js, "utf8");
fs.writeFileSync(path.join(outDir, "packaged.css"), pkg.content.css, "utf8");
console.log(`guid ${pkg.visual.guid}; js ${pkg.content.js.length} chars; css ${pkg.content.css.length} chars`);
console.log(`dataRoles: ${pkg.capabilities.dataRoles.map((r) => r.displayName).join(", ")}; privileges: ${JSON.stringify(pkg.capabilities.privileges)}`);
